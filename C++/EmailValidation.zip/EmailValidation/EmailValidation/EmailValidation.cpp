#include <iostream>
#include <regex>
using namespace std;

bool isEmail(string email);

int main()
{
	string email = "@g.co";
	cout << isEmail(email);
}

bool isEmail(string email)
{
	if (email.empty())
		return false;

	const regex pattern(R"(^[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$)");
	return regex_match(email, pattern);
}