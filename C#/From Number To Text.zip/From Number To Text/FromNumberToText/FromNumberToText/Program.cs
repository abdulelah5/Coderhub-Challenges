﻿using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Numerics;

namespace FromNumberToText
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter number or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                if (s.All(char.IsDigit))
                    Console.WriteLine(numToEng(Convert.ToInt32(s)));
            }
        }

        public static string numToEng(int n)
        {
            if (n < 0 || n > 999)
                return "Invalid number";

            string[] units = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
            string[] tens = { "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

            if (n < 20)
                return units[n];

            if (n < 100)
                return tens[n / 10] + (n % 10 != 0 ? "-" + units[n % 10] : "");

            return units[n / 100] + " hundred" + (n % 100 != 0 ? " " + numToEng(n % 100) : "");
        }
    }
}
