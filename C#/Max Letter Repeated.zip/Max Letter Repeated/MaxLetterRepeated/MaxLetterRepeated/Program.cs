﻿namespace MaxLetterRepeated
{
    public class Program
    {
        static void Main(string[] args)
        {
            bool run = true;
            while (run)
            {
                Console.WriteLine("Enter string or 0 to exit: ");
                string word = Console.ReadLine()!;
                if (word == "0")
                {
                    run = false;
                    break;
                }
                Console.WriteLine(repetitions(word) + Environment.NewLine + repSolve1(word) + Environment.NewLine + repSolve2(word));
            }
        }

        //My solution
        public static int repetitions(string s)
        {
            if (string.IsNullOrEmpty(s))
                return 0;

            Dictionary<char, int> letterCount = new Dictionary<char, int>();
            foreach (char c in s)
            {
                if (char.IsLetter(c))
                {
                    char lowerCase = char.ToLower(c);
                    if (letterCount.ContainsKey(lowerCase))
                        letterCount[lowerCase]++;
                    else
                        letterCount[lowerCase] = 1;
                }
            }

            int maxCount = 0;
            foreach (var item in letterCount)
            {
                if (item.Value > maxCount)
                    maxCount = item.Value;
            }

            return maxCount;
        }

        //Correct solutions 1
        public static int repSolve1(string s)
        {
            if (string.IsNullOrEmpty(s))
                return 0;

            int maxCount = 1, currentCount = 1;

            for (int i = 1; i < s.Length; i++)
            {
                if (s[i] == s[i - 1])
                {
                    currentCount++;
                    maxCount = Math.Max(maxCount, currentCount);
                }
                else
                {
                    currentCount = 1;
                }
            }
            return maxCount;
        }

        //Correct solutions 2
        public static int repSolve2(string s)
        {
            if (string.IsNullOrEmpty(s))
                return 0;

            return s.Select((c, index) => new { Character = c, Length = s.Substring(index).TakeWhile(x => x == c).Count() }).OrderByDescending(x => x.Length).Select(x => x.Length).FirstOrDefault();
        }
    }
}
