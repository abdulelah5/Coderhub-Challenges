﻿namespace ConvertBinaryToOctal
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter binary number or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                if (s.All(char.IsDigit))
                    Console.WriteLine(bin_to_oct(s));
            }
        }

        public static int bin_to_oct(string b)
        {
            int Decimal = Convert.ToInt32(b,2);
            string octal = Convert.ToString(Decimal, 8);
            return Convert.ToInt32(octal);
        }
    }
}
