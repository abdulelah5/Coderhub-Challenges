﻿namespace CountWords
{
    internal class Program
    {
        public static int sum_cubes(int num)
        {
            if (num < 1) return 0;

            int sum = 0;

            for (int i = 1; i <= num; i++)
            {
                sum += (i * i) * i;
            }

            return sum;
        }

        public static string date_format(string date)
        {
            if (string.IsNullOrWhiteSpace(date))
                return string.Empty;

            string[] dateD = date.Split('/');
            string result = date + "|" + (dateD[0] + "-" + dateD[1] + "-" + dateD[2]) + "|" + (dateD[1] + "/" + dateD[2] + "/" + dateD[0]);

            return result;
        }

        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                //Console.WriteLine("Enter words or 0 to exit: ");
                //Console.WriteLine("Enter date or 0 to exit: ");
                Console.WriteLine("Enter number or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                //Console.WriteLine(countWords(s));
                //Console.WriteLine(date_format(s));
                Console.WriteLine(sum_cubes(Convert.ToInt32(s)));
            }
        }

        public static int countWords(string txt)
        {
            if(string.IsNullOrEmpty(txt))
                return 0;

            string[] words = txt.Split(' ');

            return words.Length;
        }
    }
}
