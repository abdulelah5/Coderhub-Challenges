﻿namespace TotalBigger
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter number or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                if (s.All(char.IsDigit))
                    Console.WriteLine(oddsVsEvens(Convert.ToInt32(s)));
            }
        }

        public static string oddsVsEvens(int num)
        {
            int odd = 0, even = 0;
            string result = "equal";

            foreach (char i in num.ToString())
            {
                int n = Convert.ToInt32(i.ToString());

                if (n % 2 == 0)
                    even += n;
                else
                    odd += n;
            }

            if (odd > even)
                result = "odd";
            else if (even > odd)
                result = "even";

            return result;
        }
    }
}
