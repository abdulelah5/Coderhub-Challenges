﻿using System.Linq.Expressions;

namespace CalculatePostfix
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter postFix or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                Console.WriteLine(postFix(s));
            }
        }

        public static int postFix(string expr)
        {
            expr = expr.Replace(" ", "");
            Stack<int> stack = new Stack<int>();

            foreach (char c in expr)
            {
                if (char.IsDigit(c))
                {
                    // Convert char digit to int and push onto stack
                    stack.Push(c - '0');
                }
                else
                {
                    // Pop the top two operands from stack
                    int operand2 = stack.Pop();
                    if (operand2 == 0)
                    {
                        string n = stack.Pop() + operand2.ToString();
                        operand2 = Convert.ToInt32(n);
                    }

                    int operand1 = stack.Pop();
                    if (operand1 == 0)
                    {
                        string n = stack.Pop() + operand1.ToString();
                        operand1 = Convert.ToInt32(n);
                    }

                    // Perform operation based on operator
                    int result = 0;
                    switch (c)
                    {
                        case '+':
                            result = operand1 + operand2;
                            break;
                        case '-':
                            result = operand1 - operand2;
                            break;
                        case '*':
                            result = operand1 * operand2;
                            break;
                        case '/':
                            if (operand2 == 0)
                            {
                                throw new ArgumentException("Division by zero error");
                            }
                            result = operand1 / operand2;
                            break;
                        default:
                            throw new ArgumentException($"Invalid operator '{c}'");
                    }
                    stack.Push(result);
                }
            }

            // The final result should be left on the stack
            return stack.Pop();
        }
    }
}
