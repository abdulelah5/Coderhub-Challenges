﻿using System.Collections.Immutable;
using System.Text.RegularExpressions;

namespace IsValidEmail
{
    internal class Program
    {
        //ChatGPT
        public static string IsValidEmail(string email)
        {
            string pattern = @"^[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(pattern);

            return regex.IsMatch(email) ? "true" : "false";
        }

        public static bool isEmail1(string email) 
        { 
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z0-9]{1}([a-zA-Z0-9_\-\.]*)@([a-zA-Z0-9]+)\.([a-zA-Z0-9]){2,}$", System.Text.RegularExpressions.RegexOptions.CultureInvariant | System.Text.RegularExpressions.RegexOptions.Singleline); 
            bool isValidEmail = regex.IsMatch(email); 
            if (!isValidEmail) 
            { 
                return false; 
            } 
            else 
            {
                return true; 
            } 
        }

        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter email or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                Console.WriteLine(isEmail1(s));
            }
        }

        public static bool isEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
                return false;

            if (!char.IsLetter(email[0]) && !(email[0] is '-' or '_' or '.'))
                return false;

            int dotIndex = email.IndexOf('.');
            if (email.IndexOf('@') < 1 || dotIndex == -1 || !char.IsLetter(email[dotIndex - 1]) || email.Length - 1 - dotIndex < 2)
                return false;

            return true;
        }
    }
}
