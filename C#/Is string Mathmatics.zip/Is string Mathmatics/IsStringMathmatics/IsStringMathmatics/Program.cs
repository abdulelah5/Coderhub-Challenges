﻿namespace IsStringMathmatics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter mathmatics or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                Console.WriteLine("Is mathmatics ? " + math_expr(s));
            }
        }

        public static bool math_expr(string expr)
        {
            if(expr.Any(x => char.IsLetter(x)))
                return false;

            bool result = false;
            int countFalse = 0;
            foreach (char c in expr)
            {
                string s = c.ToString();
                if (!s.All(char.IsDigit) && !(s is "+" or "-" or "*" or "/" or "%"))
                    countFalse++;
            }

            result = countFalse == 0;

            return result;
        }
    }
}
