﻿namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter word or 0 to exit: ");
                string s = Console.ReadLine()!;

                Console.WriteLine("Enter number: ");
                string snum = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                if(snum.All(char.IsDigit))
                    Console.WriteLine(first_n_vowels(s,Convert.ToInt32(snum)));
            }
        }

        public static string first_n_vowels(string phrase, int n)
        {
            string result = new string(phrase.Where(x => char.ToUpper(x) is 'A' or 'E' or 'I' or 'O' or 'U').Select(c => c).ToArray());

            if (result.Length < n)
                result = "invalid";

            return result;
        }
    }
}
