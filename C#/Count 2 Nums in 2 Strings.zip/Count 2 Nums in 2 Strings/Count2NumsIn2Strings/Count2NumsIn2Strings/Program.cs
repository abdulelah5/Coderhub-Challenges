﻿using System.Dynamic;

namespace Count2NumsIn2Strings
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;
            while (run)
            {
                Console.WriteLine("**** Enter 0 to exit ****");
                string op = Console.ReadLine()!;
                if(op == "0")
                {
                    run = false;
                    break;
                }

                Console.WriteLine("Enter first string: ");
                string num1 = Console.ReadLine()!;
                Console.WriteLine("Enter second string: ");
                string num2 = Console.ReadLine()!;

                Console.WriteLine("Result -> " + addStrNums(num1,num2));
            }
        }

        public static string addStrNums(string num1, string num2)
        {
            string result = "-1";

            if(num1.All(char.IsDigit) && num2.All(char.IsDigit))
            {
                int total = Convert.ToInt32(num1) + Convert.ToInt32(num2);
                result = total.ToString();
            }

            return result;
        }
    }
}
