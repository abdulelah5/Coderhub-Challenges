﻿namespace ArrowDuplicates
{
    public class Program
    {
        static void Main(string[] args)
        {
            bool run = false;

            while (run)
            {
                Console.WriteLine("Enter words or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                Console.WriteLine(arrowDuplicates(s));
            }
            int[] arr1 = [19, 29], arr2 = [10, 20];
            int[] result = Subtract.sub_arrays(arr1, arr2);
            for (int i = 0; i < result.Length; i++)
            {
                Console.WriteLine(result[i]);
            }
        }

        public static string arrowDuplicates(string word)
        {
            if(string.IsNullOrWhiteSpace(word))
                return string.Empty;

            word = word.ToLower();
            char[] chars = word.ToCharArray();
            string result = string.Empty;

            foreach (char c in word)
            {
                int count = chars.Where(x => x == c).Count();
                if (count < 2)
                    result += ">";
                else 
                    result += "<";
            }

            return result;
        }
    }
}
