﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrowDuplicates
{
    public class Subtract
    {
        public static int[] sub_arrays(int[] arr1, int[] arr2)
        {
            if(arr1.Length != arr2.Length || arr1.Length < 1)
                return new int[0];

            int[] result = new int[arr1.Length];

            for (int i = 0; i < arr1.Length; i++)
            {
                result[i] = arr2[i] - arr1[i];
            }

            return result;
        }
    }
}
