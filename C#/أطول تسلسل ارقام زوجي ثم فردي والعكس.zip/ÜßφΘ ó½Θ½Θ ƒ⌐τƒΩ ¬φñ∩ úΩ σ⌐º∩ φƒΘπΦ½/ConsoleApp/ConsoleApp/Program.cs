﻿namespace ConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter number or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                if (s.All(char.IsDigit))
                    Console.WriteLine(longestAlternatingSubstring(s));
            }
        }

        public static string longestAlternatingSubstring(string digits)
        {
            string result = string.Empty;
            string seq = string.Empty;
            string temp = string.Empty;

            foreach (char c in digits)
            {
                int num = Convert.ToInt32(c.ToString());

                if (num % 2 == 0 && temp is "" or "odd")
                {
                    seq += num;
                    temp = "even";
                }
                else if (num % 2 != 0 && temp is "" or "even")
                {
                    seq += num;
                    temp = "odd";
                }
                else
                {
                    if (seq.Length > result.Length)
                        result = seq;

                    seq = num.ToString();
                    temp = num % 2 == 0 ? "even" : "odd";
                }
            }

            return result;
        }
    }
}
