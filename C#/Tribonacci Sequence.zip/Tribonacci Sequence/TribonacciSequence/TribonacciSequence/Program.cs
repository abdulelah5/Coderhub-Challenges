﻿namespace TribonacciSequence
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter number or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                if (s.All(char.IsDigit))
                {
                    int[] ints = tribonacci(Convert.ToInt32(s));
                    for (int i = 0; i < ints.Length; i++)
                    {
                        Console.Write(i == 0 ? ints[i] : "," + ints[i]);
                    }
                    Console.WriteLine();
                }
            }
        }

        public static int[] tribonacci(int num)
        {
            if (num <= 0)
                return new int[0];

            int[] tribonacci = new int[num];

            if (num >= 1)
                tribonacci[0] = 1;
            if (num >= 2)
                tribonacci[1] = 1;
            if (num >= 3)
                tribonacci[2] = 1;

            for (int i = 3; i < num; i++)
            {
                tribonacci[i] = tribonacci[i - 1] + tribonacci[i - 2] + tribonacci[i - 3];
            }

            return tribonacci;
        }
    }
}
