﻿namespace UniqeNumberArray
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] ints = [2, 3, 2, 6, 2];
            int[] result = unique(ints);
            for (var z = 0; z < result.Length; z++)
            {
                Console.WriteLine(result[z]);
            }
        }

        public static int[] unique(int[] arr)
        {
            List<int> ints = new List<int>();
            Dictionary<int, int> repCount = new Dictionary<int, int>();

            for (int i = 0; i < arr.Length; i++)
            {
                if (repCount.ContainsKey(arr[i]))
                    repCount[arr[i]]++;
                else
                    repCount[arr[i]] = 1;
            }

            foreach (int i in repCount.Where(x => x.Value == 1).Select(z => z.Key))
            {
                ints.Add(i);
            }

            return ints.ToArray();
        }
    }
}
