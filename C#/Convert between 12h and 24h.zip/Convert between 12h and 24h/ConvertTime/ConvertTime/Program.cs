﻿namespace ConvertTime
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool run = true;

            while (run)
            {
                Console.WriteLine("Enter time or 0 to exit: ");
                string s = Console.ReadLine()!;

                if (s == "0")
                {
                    run = false;
                    break;
                }

                if(s.Length >= 4)
                    Console.WriteLine(convert_time(s));
            }
        }

        public static string convert_time(string time)
        {
            string result = "00:00";

            if (time.IndexOf(":") < 2) //valid format -> 7:45, must be -> 07:45
                time = 0 + time;

            if (time.Any(x => char.IsLetter(x)))
                result = DateTime.ParseExact(time, "hh:mm tt", null).ToString("HH:mm"); //from 12 to 24
            else 
                result = DateTime.ParseExact(time, "HH:mm", null).ToString("hh:mm tt").ToLower(); //from 24 to 12

            if (result.StartsWith("0")) //return to -> 7:45 
                result = result.Substring(1);

            return result;
        }
    }
}
