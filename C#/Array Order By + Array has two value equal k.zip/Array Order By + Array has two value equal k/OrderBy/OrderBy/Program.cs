﻿namespace OrderBy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //string[] names = ["Khaled Bader", "Khaled Bader", "Mohammed Yahya"];
            //string order = "DESC";

            //string[] result = namesSort(names,order);
            //for (int i = 0; i < result.Length; i++)
            //{
            //    Console.WriteLine(result[i]);
            //}

            int[] numArray = [14, 8, 12, 9];
            int k = 21;
            Console.WriteLine(kSumSubset(numArray, k));
        }

        public static string[] namesSort(string[] namesArray, string order)
        {
            if (namesArray.Length < 1 || string.IsNullOrEmpty(order))
                return new string[0];

            List<string> names = namesArray.ToList();

            if (order.ToUpper() == "ASC")
                names = names.OrderBy(x => x).ToList();
            else
                names = names.OrderByDescending(x => x).ToList();

            return names.ToArray();
        }

        //Result is perfect but they give incorrect
        public static bool kSumSubset(int[] numArray, int k)
        {
            if (numArray.Length < 1)
                return false;
            
            for (int i = 0; i < numArray.Length; i++)
            {
                for (int j = i; j < numArray.Length; j++)
                {
                    if (numArray[i] + numArray[j] == k)
                        return true;
                }
            }

            return false;
        }

        public static bool chatGPT(int[] numArray, int k)
        {
            int n = numArray.Length;
            bool[,] dp = new bool[n + 1, k + 1];

            // إذا كان k هو 0، فإنه دائماً يمكن أن يكون الكل مجموعة فارغة
            for (int i = 0; i <= n; i++)
            {
                dp[i, 0] = true;
            }

            // إذا كان i هو 0 وk ليس 0، فلا يمكن تحقيق المجموع
            for (int j = 1; j <= k; j++)
            {
                dp[0, j] = false;
            }

            // املأ باقي الجدول
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= k; j++)
                {
                    if (numArray[i - 1] > j)
                    {
                        dp[i, j] = dp[i - 1, j];
                    }
                    else
                    {
                        dp[i, j] = dp[i - 1, j] || dp[i - 1, j - numArray[i - 1]];
                    }
                }
            }

            return dp[n, k];
        }
    }
}
